var keystone = require('keystone');
var Types = keystone.Field.Types;

var Route = new keystone.List('Route', {
    map: { name: 'name' },
    autokey: { from: 'name', path: 'key' },
});

Route.add({
    name: {
        type: String,
        initial: true
    },
    
    category: {
        type: Types.Relationship,
        ref: 'RouteCategory'
    },

    priceOptions: {
        type: Types.Relationship,
        ref: 'RoutePriceOption',
        label: "Prices",
        many: true,
        noedit: true,
    },

    state: {
        type: Types.Select,
        options: 'draft, published, archived',
        default: 'draft',
        index: true
    },

    image: {
        type: Types.CloudinaryImage,
        folder: "routes"
    },

    tags: {
        type: Types.TextArray
    },

    description: {
        type: Types.Html,
        wysiwyg: true,
        height: 150
    },

    createdDate: {
        type: Date,
        default: Date.now
    },
    modifiedDate: {
        type: Date,
        default: Date.now
    },
});

Route.schema.virtual('options').get(function () {
    return this.priceOptions.map(op => ({
        _id: op._id,
        quantity: (op.option || {}).quantity,
        currency: (op.currency || "KES").replace('Ksh', "KES"),
        offerPrice: op.offerPrice || 0,
        price: op.price || 0,
    })).distinctBy(op => op.quantity);
});

Route.schema.virtual('defaultOption').get(function () {
    return this.options.orderBy(o => o.price).last();
});

Route.schema.virtual('currency').get(function () {
    var defaultOption = this.defaultOption || this.priceOptions.first() || {};
    return (defaultOption ? defaultOption.currency || "KES" : "KES").replace('Ksh', "KES");
});

Route.schema.virtual('price').get(function () {
    var defaultOption = this.defaultOption || this.priceOptions.first() || {};
    return defaultOption ? defaultOption.price : null;
});

Route.schema.virtual('priceValidUntil').get(function () {
    var today = new Date();

    var firstStr = today.toISOString().substr(0, 8) + "01";
    var expiryStr = new Date(firstStr).addMonths(1).addSeconds(-1).toISOString();

    if (expiryStr.startsWith("01")) 
        expiryStr = expiryStr.replace(/^01/, "20");
    
    return expiryStr;
});

Route.defaultColumns = 'name, category, state, tags, createdDate, modifiedDate';

keystone.deepPopulate(Route.schema);

Route.register();