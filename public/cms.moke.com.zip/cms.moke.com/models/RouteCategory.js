var keystone = require('keystone');
var Types = keystone.Field.Types;

/**
 * RouteCategory Model
 * ==================
 */

var RouteCategory = new keystone.List('RouteCategory', {
    autokey: {from: 'name', path: 'key', unique: true},
});

RouteCategory.add({
    name: {type: String, required: true, initial: true},
    image: {type: Types.CloudinaryImage, folder: "category"},
    pageTitle: {type: String},
    description: {type: Types.Html, wysiwyg: true, height: 150},
    modifiedDate: {type: Date, default: Date.now},
    priorityTags: {type: Types.TextArray}
});

RouteCategory.relationship({ref: 'Route', refPath: 'category'});
RouteCategory.relationship({ref: 'RouteCategory', refPath: 'category'});

RouteCategory.defaultColumns = 'name, image, pageTitle, priorityTags, description';

RouteCategory.schema.pre('save', function(next){
    var that = this;

    that.modifiedDate = new Date();
    next();
});

RouteCategory.register();
