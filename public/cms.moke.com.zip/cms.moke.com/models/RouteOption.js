var keystone = require('keystone');
var Types = keystone.Field.Types;

/**
 * RouteOption Model
 * ==================
 */

var RouteOption = new keystone.List('RouteOption', {
	map: {name: 'quantity'},
	autokey: {from: 'quantity', path: 'key', unique: true},
});

RouteOption.add({
	quantity: {type: String, initial: true, required: true},
	description: {type: Types.Html, wysiwyg: true, height: 150}
});

RouteOption.relationship({ref: 'RoutePriceOption', path: 'option', refPath: 'option'});

RouteOption.defaultColumns = 'quantity, description';
RouteOption.register();
