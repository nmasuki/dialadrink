var keystone = require('keystone');
var Types = keystone.Field.Types;

/**
 * RoutePriceOption Model
 * ==================
 */
var RoutePriceOption = new keystone.List('RoutePriceOption', {
    singular: 'Route Price',
    prural: 'Route Prices',
    map: {name: 'label'},
});

RoutePriceOption.add({
    option: {type: Types.Relationship, ref: 'RouteOption', many: false},
    product: {type: Types.Relationship, ref: 'Route', many: false},

    currency: {type: String},
    price: {type: Types.Number},
    offerPrice: {type: Types.Number},
    
	inStock: { type: Types.Boolean },

    optionText: {type: String, hidden: true}
});

RoutePriceOption.schema.virtual('percentOffer').get(function () {
    if (this && !!this.offerPrice && this.price > this.offerPrice) {
        var discount = this.price - this.offerPrice;
        var percent = Math.round(100 * discount / defaultOption.price);
        return percent || null;
    }

    return null;
});

RoutePriceOption.relationship({ref: 'Route', path: 'product', refPath: 'priceOptions'});
RoutePriceOption.relationship({ref: 'RouteOption', path: 'priceOptions', refPath: 'priceOptions'});

RoutePriceOption.schema.virtual('label').get(function () {
    return `${this.optionText || ''} (${this.currency || 'KES'} ${this.price || ''})`;
});

RoutePriceOption.schema.pre('save', function (next) {
    var ppo = this;

    function updateRoute(next) {
        if (!ppo.product)
            return next();

        var productId = ppo.product._id || ppo.product;
        keystone.list("Route").model.findOne({_id: productId})
            .deepPopulate("priceOptions.option")
            .exec((err, product) => {
                if (err || !product)
                    return next(err);

                var thisOption = product.priceOptions.find(po => "" + po.option._id == "" + ppo.option);

                if (!thisOption)
                    product.priceOptions.push(thisOption = ppo);

                //product.priceOptions = product.priceOptions.distinctBy(op => op.option.quantity);
                thisOption.option = ppo.option;
                thisOption.product = ppo.product;

                thisOption.currency = ppo.currency;
                thisOption.price = ppo.price;
                thisOption.offerPrice = ppo.offerPrice;
                thisOption.optionText = ppo.optionText;

                product.save();
                next();
            });
    }

    if (ppo.option && ppo.option.quantity) {
        ppo.optionText = ppo.option.quantity;
        updateRoute(next);
    } else if (ppo.option) {
        keystone.list("RouteOption").model.findOne({_id: ppo.option._id || ppo.option})
            .populate('option')
            .exec(function (err, option) {
                if (err || !option)
                    return next(err);

                ppo.optionText = option.quantity;
                updateRoute(next);
            });
    } else if (ppo.optionText) {
        var filter = {"$or": [{quantity: ppo.optionText.trim()}, {"key": ppo.optionText.cleanId()}]};
        keystone.list("RouteOption").model.findOne(filter)
            .populate('option')
            .exec(function (err, option) {
                if (err || !option)
                    return next(err);

                ppo.optionText = option.quantity;
                ppo.option = option;
                updateRoute(next);
            });
    } else {
        next();
    }
});

RoutePriceOption.defaultColumns = 'option, product, currency, price, offerPrice';
RoutePriceOption.register();
