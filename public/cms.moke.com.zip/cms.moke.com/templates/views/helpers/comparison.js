module.exports = function () {
	var _helpers = {};

	return _helpers;
}
